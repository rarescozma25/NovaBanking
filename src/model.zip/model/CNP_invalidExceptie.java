package model;

public class CNP_invalidExceptie extends RuntimeException {
    public CNP_invalidExceptie(String message) {
        super(message);
    }
}
