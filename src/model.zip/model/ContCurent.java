package model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ContCurent extends Cont{
    private TipContCurent tip;
    private LocalDate ultimaDobanda_Aplicata;
    public ContCurent(Client client, Bani soldInitial, TipContCurent tip) {
        super(client, soldInitial); // IBAN-ul este generat în super
        this.tip = tip;
        this.ultimaDobanda_Aplicata = LocalDate.now();
    }


    public TipContCurent getTip() {
        return tip;
    }
    public void setTip(TipContCurent tip) {
        this.tip = tip;
    }

    public void calculeazaDobanda(LocalDate dataCurenta) {
        long luniTrecute = ChronoUnit.MONTHS.between(ultimaDobanda_Aplicata, dataCurenta);
        if (luniTrecute>=6) {
            super.setSold(new Bani(super.getSold().getValoare() * (1 + tip.getDobanda()), super.getSold().getMoneda()));
            ultimaDobanda_Aplicata = dataCurenta;
            System.out.println("Dobanda de tipul " + tip.getDobanda() + " a fost aplicata!");
        }
        else{
            System.out.println("Nu au trecut suficiente luni pentru a aplica dobanda! ");
        }
    }

}
