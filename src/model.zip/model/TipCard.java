package model;

public enum TipCard {
    VISA,
    MASTERCARD,
    AMEX,
    MAESTRO,
}
