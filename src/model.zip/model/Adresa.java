package model;

public record Adresa(String adresa, String oras, String codPostal) {

}
