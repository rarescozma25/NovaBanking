package model;

public class FonduriInsuficienteExceptie extends RuntimeException{
    public FonduriInsuficienteExceptie(String mesaj){
        super(mesaj);
    }
}
