package model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ContEconomii extends Cont{
    private TipContEconomii tip;
    private LocalDate ultimaDobanda_Aplicata;

    public ContEconomii(Client client, Bani soldInitial, TipContEconomii tip) {
        super(client, soldInitial);
        this.tip = tip;
        this.ultimaDobanda_Aplicata=LocalDate.now();
    }

    public TipContEconomii getTip() {
        return tip;
    }

    public void setTip(TipContEconomii tip) {
        this.tip = tip;
    }
    @Override
    public void calculeazaDobanda(LocalDate dataCurenta) {
        long luniTrecute = ChronoUnit.MONTHS.between(ultimaDobanda_Aplicata, dataCurenta);

        if (luniTrecute >= tip.getDurata()) {
            float valoareNoua = super.getSold().getValoare() * (1 + tip.getDobanda());
            super.setSold(new Bani(valoareNoua, super.getSold().getMoneda()));
            ultimaDobanda_Aplicata = dataCurenta;
            System.out.println("Dobanda de " + tip.getDobanda() + " a fost aplicata.");
        } else {
            System.out.println("Nu au trecut suficiente luni pentru a aplica dobanda! ");
        }
    }
}
